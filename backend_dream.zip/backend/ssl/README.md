# SSL Certificate Setup

This directory contains SSL certificates for HTTPS support.

## For Development (Self-Signed Certificate)
Run the following command to generate a self-signed certificate:
```bash
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes
```

## For Production (Let's Encrypt)
1. Install certbot: `sudo apt-get install certbot`
2. Generate certificate: `sudo certbot certonly --standalone -d yourdomain.com`
3. Copy certificates to this directory:
   - `/etc/letsencrypt/live/yourdomain.com/fullchain.pem` → `cert.pem`
   - `/etc/letsencrypt/live/yourdomain.com/privkey.pem` → `key.pem`

## File Structure
- `cert.pem` - SSL certificate
- `key.pem` - Private key
- `generate-self-signed.sh` - Script to generate self-signed certificate 