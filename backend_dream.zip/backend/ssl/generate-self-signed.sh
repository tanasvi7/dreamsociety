#!/bin/bash

# Generate self-signed SSL certificate for development
echo "Generating self-signed SSL certificate..."

# Create SSL directory if it doesn't exist
mkdir -p ssl

# Generate self-signed certificate
openssl req -x509 -newkey rsa:4096 -keyout ssl/key.pem -out ssl/cert.pem -days 365 -nodes -subj "/C=IN/ST=State/L=City/O=DreamSociety/CN=103.127.146.54"

echo "Self-signed certificate generated successfully!"
echo "Files created:"
echo "  - ssl/cert.pem (certificate)"
echo "  - ssl/key.pem (private key)"
echo ""
echo "Note: For production, use Let's Encrypt certificates instead." 